#ifndef __MEDIT
  extern Canvas   cv;
  extern ubyte    ddebug,quiet,imprim,option,morphing,animate,saveimg,imgtype;
  extern int      animdep,animfin;
  extern char    *imgtyp[];
#endif
