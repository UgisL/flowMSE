long verbosity=1;
  long mpirank =0;
void  ShowDebugStack(){}
